# RoboBibb.GitHub.io
see our team website here: https://robobibb.github.io/

This website is built by the RoboBibb programming and marketing teams using the [W3.CSS](https://www.w3schools.com/w3css/) CSS framework, a lightweight web framework.

# Who to contact
Although hopefully anyone on website team knows how to fix most problems, these are the people who best understand each page. If you find an problem feel free to open an issue on github or contact one of these people.

- [Homepage](https://robobibb.github.io) -> everyone :)
- [Members](https://robobibb.github.io/members/) -> Tate ( @dvtate )
- [About us](https://robobibb.github.io/about/) -> Theresia ( @theresiajahja )
- [Sponsors](https://robobibb.github.io/sponsors/) -> Saea ( @kim54771 )
- [Outreach/Impact](https://robobibb.github.io/outreach/) -> Tate
- [Skills building](https://robobibb.github.io/skills) -> Tate, Theresia
- [styles/main.css](https://robobibb.github.io/styles/main.css) -> Tate
- [scripts/main.js](https://robobibb.github.io/scripts/main.js) (topbar + footer) -> Tate
- [Robots](https://robobibb.github.io/robots) -> Tate
- [Sub-team sections](https://robobibb.github.io) -> Tate, marketing team, captains, keely
- [Updates (also steve bindings)](https://robobibb.github.io/updates) -> Tate, update author
- Content/text changes -> anyone, keely
- Other/Unsure -> Tate
